<?php

interface LoggerInterface
{}
